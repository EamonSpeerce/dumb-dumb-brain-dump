package com.example.myapplication.View.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.myapplication.View.TaskViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskScreen(taskViewModel: TaskViewModel) {

    var task by remember { mutableStateOf("") }

    var description by remember { mutableStateOf("") }

    var days by remember { mutableStateOf(1) }
    val taskList by taskViewModel.tasks.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {Text("Repeated Tasks")},
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Red,
                    titleContentColor = Color.White
                )
            )
        }
    )
    { innerPadding ->
        Column(modifier = Modifier.fillMaxSize()
            .padding(innerPadding)
            .padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = task,
                    onValueChange = { task = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Red,
                        unfocusedIndicatorColor = Color.Red,
                        focusedContainerColor = Color.Red,
                        unfocusedContainerColor = Color.Red
                    )
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Red,
                        unfocusedIndicatorColor = Color.Red,
                        focusedContainerColor = Color.Red,
                        unfocusedContainerColor = Color.Red
                    )
                )
                Text("Repeat every")
                OutlinedTextField(
                    value = days.toString(),
                    onValueChange = { input ->
                        val parsed = input.toIntOrNull()
                        if (parsed != null && parsed in 1..365) days = parsed
                    },
                    label = { Text("Days") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(80.dp),
                    shape = RoundedCornerShape(22.dp)
                )
                Text("days")

                Button(
                    onClick = {
                        if (task.isNotBlank()) {
                            taskViewModel.addTask(name = task, desc = description, repeatPeriod = daysToMillis(days))
                            task = ""
                            description = ""
                            days = 0
                        }
                    },
                    colors = ButtonDefaults.buttonColors(Color.Red)
                ) {
                    Text("Add")
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.Red)
            Spacer(modifier = Modifier.height(16.dp))
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(items = taskList, key = {it.id}) {task ->
                var isEditing by remember(task.id) { mutableStateOf(false) }
                var newTitle by remember(task.id) { mutableStateOf(task.name)}
                var newDescription by remember(task.description) { mutableStateOf(task.description)}
                var newRepeatPeriod by remember(task.repeatPeriod) { mutableStateOf(task.repeatPeriod)}

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                taskViewModel.completeTask(task)
                            },
                            colors = ButtonDefaults.buttonColors()
                        ) {
                            Text("Complete")
                        }
                        if (isEditing) {
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = {newTitle = it},
                                modifier = Modifier.width(160.dp),
                                shape = RoundedCornerShape(22.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedIndicatorColor = Color.Red,
                                    unfocusedIndicatorColor = Color.Red,
                                    focusedContainerColor = Color.Red,
                                    unfocusedContainerColor = Color.Red
                                )
                            )
                            OutlinedTextField(
                                value = newDescription,
                                onValueChange = {newDescription = it},
                                modifier = Modifier.width(160.dp),
                                shape = RoundedCornerShape(22.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedIndicatorColor = Color.Red,
                                    unfocusedIndicatorColor = Color.Red,
                                    focusedContainerColor = Color.Red,
                                    unfocusedContainerColor = Color.Red
                                )
                            )

                            Button(
                                onClick = {
                                    taskViewModel.editTask(task.copy(name = newTitle, description = newDescription, repeatPeriod = newRepeatPeriod))
                                    isEditing = false
                                },
                                modifier = Modifier.padding(start = 4.dp),
                                colors = ButtonDefaults.buttonColors(Color.Red))
                            {
                                Text("Save")
                            }
                        } else {
                            Text(task.name,
                                modifier = Modifier.padding(start = 8.dp),
                                style = if (task.isPastActionDeadline)
                                    LocalTextStyle.current.copy(color = Color.Red)
                                else LocalTextStyle.current
                            )

                        }

                    }
                    Row {
                        IconButton(onClick = {
                            if (!isEditing) newTitle = task.name
                            isEditing = !isEditing
                        }) {
                            Icon(Icons.Default.Edit,
                                contentDescription = "Edit")
                        }

                        IconButton(onClick = {
                            taskViewModel.deleteTask(task)
                        }) {
                            Icon(Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

private fun daysToMillis(days: Int): Long {
    return days.toLong() * 24 * 60 * 60 * 1000
}
